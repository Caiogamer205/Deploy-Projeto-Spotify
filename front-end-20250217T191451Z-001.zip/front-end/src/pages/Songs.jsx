import React from "react";
import Main from "../components/Main";

const Songs = () => {
  return <Main type="songs" />;
};

export default Songs;
