import React from "react";
import Main from "../components/Main";

const Artists = () => {
  return <Main type="artists" />;
};

export default Artists;
